import 'dotenv/config';

const androidPackage = process.env.EXPO_PUBLIC_ANDROID_PACKAGE || 'com.motogo.app';
const appName = process.env.EXPO_PUBLIC_APP_NAME || 'MotoGo';
const easProjectId = process.env.EAS_PROJECT_ID || 'REPLACE_WITH_EAS_PROJECT_ID';

export default ({ config }) => ({
  ...config,
  name: appName,
  slug: 'motogo-rides',
  owner: process.env.EXPO_PUBLIC_EXPO_OWNER || undefined,
  version: '1.0.0',
  orientation: 'portrait',
  userInterfaceStyle: 'light',
  newArchEnabled: true,
  android: {
    ...config.android,
    package: androidPackage,
    versionCode: 1,
    permissions: [],
    edgeToEdgeEnabled: true,
  },
  ios: {
    ...config.ios,
    bundleIdentifier: androidPackage,
    buildNumber: '1',
  },
  extra: {
    ...config.extra,
    eas: { projectId: easProjectId },
  },
});
