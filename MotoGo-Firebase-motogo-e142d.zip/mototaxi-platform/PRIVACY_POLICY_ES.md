# Política de privacidad de MotoGo (borrador para revisión legal)

**Última actualización:** [FECHA]
**Responsable del tratamiento:** [RAZÓN SOCIAL / TITULAR]
**Contacto de privacidad:** [CORREO DE CONTACTO]

MotoGo es una plataforma de intermediación de viajes en motocicleta. Esta política describe, de forma preliminar, el tratamiento de datos que puede ser necesario para operar el servicio. Debe completarse y revisarse legalmente en Chile, Colombia y Perú antes de publicar la aplicación.

## Datos que podemos tratar
- Datos de cuenta: nombre, correo electrónico, identificador de usuario y rol.
- Datos del viaje: origen, destino, país, tarifa, estado, conductor asignado e historial.
- Datos de conductor: información de perfil y estado de aprobación. No se deben recopilar documentos de identidad hasta definir un proceso seguro y una base legal.
- Datos de soporte, seguridad, prevención de fraude y registros técnicos.
- Ubicación precisa: **esta versión no integra todavía GPS en tiempo real**. Si se incorpora, esta sección, los permisos de Android y los controles de consentimiento deben actualizarse antes de publicar.

## Finalidades
Crear y proteger cuentas, solicitar y gestionar viajes, calcular comisiones, prevenir fraude, atender consultas y cumplir obligaciones legales aplicables.

## Compartición y proveedores
Los datos pueden ser procesados por proveedores de infraestructura como Google/Firebase para autenticación, almacenamiento y ejecución del backend. Añadir aquí los demás proveedores reales antes de publicar. No afirmar que no se comparten datos si se utilizan SDK de terceros.

## Conservación y seguridad
Conservaremos los datos solo durante el tiempo necesario para prestar el servicio, resolver disputas y cumplir obligaciones legales. Aplicaremos controles de acceso y medidas de seguridad razonables; ningún sistema puede garantizar seguridad absoluta.

## Derechos y contacto
Las personas podrán solicitar acceso, rectificación, eliminación u otros derechos aplicables escribiendo a [CORREO]. Añadir los procedimientos, plazos, responsable y requisitos exigidos en cada país.

## Menores
El servicio no está dirigido a menores de edad. Definir y aplicar una política de edad y verificación antes del lanzamiento.

## Cambios
Publicaremos las actualizaciones de esta política en [URL PÚBLICA].

> No publicar este borrador sin completar los campos entre corchetes, verificar las prácticas reales de la app y obtener revisión legal local.
