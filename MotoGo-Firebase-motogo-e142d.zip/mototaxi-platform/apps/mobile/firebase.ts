import AsyncStorage from '@react-native-async-storage/async-storage';
import { getApp, getApps, initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getFunctions } from 'firebase/functions';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID,
  appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID,
  messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
};

const missing = Object.entries(firebaseConfig).filter(([key, value]) => key !== 'messagingSenderId' && !value).map(([key]) => key);
export const firebaseConfigured = missing.length === 0;
export const firebaseConfigError = firebaseConfigured ? '' : `Faltan variables Firebase: ${missing.join(', ')}`;

const app = getApps().length ? getApp() : initializeApp(firebaseConfigured ? firebaseConfig : { apiKey: 'missing-config', projectId: 'missing-config', appId: 'missing-config' });
let auth;
try {
  auth = initializeAuth(app, { persistence: getReactNativePersistence(AsyncStorage) });
} catch {
  auth = getAuth(app);
}
export { auth };
export const functions = getFunctions(app, 'southamerica-west1');
export const firestore = getFirestore(app);
