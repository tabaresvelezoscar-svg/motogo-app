import React, { useEffect, useMemo, useState } from 'react';
import { SafeAreaView, View, Text, TouchableOpacity, TextInput, ScrollView, StyleSheet, StatusBar, ActivityIndicator } from 'react-native';
import { onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, User } from 'firebase/auth';
import { collection, doc, onSnapshot, query, where } from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { auth, firebaseConfigured, firebaseConfigError, firestore, functions } from './firebase';

type Role = 'passenger' | 'rider' | 'owner';
type Country = 'CL' | 'CO' | 'PE';
type Trip = { tripId: string; estado: string; pais: Country; moneda: string; origen: string; destino: string; tarifa_minor_units: number; comision_minor_units?: number; saldo_despues_comision_minor_units?: number; conductor_id?: string | null; pasajero_id?: string; comision_aplicada?: boolean };
const countries: Record<Country, { name: string; currency: string; symbol: string }> = { CL: { name: 'Chile', currency: 'CLP', symbol: '$' }, CO: { name: 'Colombia', currency: 'COP', symbol: '$' }, PE: { name: 'Perú', currency: 'PEN', symbol: 'S/' } };
const money = (n = 0, c: Country = 'CL') => `${countries[c].symbol}${(c === 'PE' ? n / 100 : n).toLocaleString('es-CL', { maximumFractionDigits: c === 'PE' ? 2 : 0 })} ${countries[c].currency}`;
const callable = <T, R>(name: string) => httpsCallable<T, R>(functions, name);

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<Role>('passenger');
  const [profileReady, setProfileReady] = useState(false);
  const [country, setCountry] = useState<Country>('CL');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('signup');
  const [origin, setOrigin] = useState('Mi ubicación');
  const [destination, setDestination] = useState('');
  const [tripId, setTripId] = useState('');
  const [trip, setTrip] = useState<Trip | null>(null);
  const [availableTrips, setAvailableTrips] = useState<Trip[]>([]);
  const [wallet, setWallet] = useState(0);
  const [approved, setApproved] = useState(false);
  const [active, setActive] = useState(false);
  const [available, setAvailable] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  useEffect(() => onAuthStateChanged(auth, async (nextUser) => {
    setUser(nextUser); setProfileReady(false); setTrip(null); setTripId(''); setAvailableTrips([]);
    if (!nextUser) { setProfileReady(true); return; }
    try {
      const token = await nextUser.getIdTokenResult(true);
      setIsAdmin(token.claims.admin === true);
      const { getDoc } = await import('firebase/firestore');
      const profile = await getDoc(doc(firestore, 'users', nextUser.uid));
      if (profile.exists()) {
        const data = profile.data();
        setRole(data.role === 'rider' ? 'rider' : data.role === 'owner' ? 'owner' : 'passenger');
        if (data.country && countries[data.country as Country]) setCountry(data.country as Country);
        setDisplayName(data.displayName || '');
        if (data.role === 'owner' && token.claims.admin !== true) { setRole('passenger'); setError('El panel de propietario requiere el permiso administrativo del servidor.'); }
      } else setNotice('Tu cuenta aún no tiene perfil. Cierra sesión y crea un perfil pasajero o conductor.');
      const driver = await getDoc(doc(firestore, 'conductores', nextUser.uid));
      if (driver.exists()) { const d = driver.data(); setWallet(d.saldo_billetera_interna_minor_units || 0); setApproved(d.approved === true); setActive(d.estado_activo === true); setAvailable(d.disponible === true); }
    } catch (e: any) { setError(e.message || 'No se pudo cargar el perfil.'); }
    setProfileReady(true);
  }), []);

  useEffect(() => {
    if (!user || !tripId) { setTrip(null); return; }
    return onSnapshot(doc(firestore, 'viajes', tripId), (snap) => {
      if (snap.exists()) setTrip({ tripId: snap.id, ...snap.data() } as Trip);
    }, (e) => setError(`No se pudo observar el viaje: ${e.message}`));
  }, [user, tripId]);

  useEffect(() => {
    if (!user || role !== 'rider' || !approved || !active || !available) return;
    let cancelled = false;
    const refresh = async () => {
      try { const result = await callable<Record<string, never>, { trips: Trip[] }>('listAvailableTrips')({}); if (!cancelled) setAvailableTrips(result.data.trips); }
      catch (e: any) { if (!cancelled) setError(e.message || 'No se pudieron cargar los viajes.'); }
    };
    refresh();
    const interval = setInterval(refresh, 6000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [user, role, approved, active, available]);

  const run = async (task: () => Promise<any>, success?: string) => {
    setBusy(true); setError(''); setNotice('');
    try { const result = await task(); if (success) setNotice(success); return result; }
    catch (e: any) { setError(e?.message || 'La operación falló.'); return null; }
    finally { setBusy(false); }
  };
  const handleAuth = () => run(async () => {
    if (!firebaseConfigured) throw new Error(firebaseConfigError);
    if (!email.trim() || password.length < 6) throw new Error('Ingresa un correo y una contraseña de al menos 6 caracteres.');
    if (authMode === 'login') await signInWithEmailAndPassword(auth, email.trim(), password);
    else {
      if (!displayName.trim()) throw new Error('Escribe tu nombre.');
      const signupRole: 'passenger' | 'rider' = role === 'rider' ? 'rider' : 'passenger';
      const credential = await createUserWithEmailAndPassword(auth, email.trim(), password);
      try { await callable<{ role: 'passenger' | 'rider'; displayName: string; country: Country }, { ok: boolean }>('registerProfile')({ role: signupRole, displayName: displayName.trim(), country }); }
      catch (e) { await signOut(auth); throw e; }
      setRole(signupRole); setProfileReady(true);
      if (signupRole === 'rider') { setApproved(false); setActive(true); setAvailable(false); setWallet(0); }
      setNotice(signupRole === 'rider' ? 'Cuenta creada. El propietario debe aprobar al conductor antes de habilitar viajes.' : 'Cuenta pasajero creada. Ya puedes solicitar un viaje.');
    }
  });
  const logout = () => run(() => signOut(auth), 'Sesión cerrada.');
  const requestTrip = () => run(async () => {
    if (!origin.trim() || !destination.trim()) throw new Error('Completa origen y destino.');
    const res = await callable<{ country: Country; origin: string; destination: string }, { tripId: string; fareMinorUnits: number; currency: string }>('requestTrip')({ country, origin, destination });
    setTripId(res.data.tripId); setNotice(`Viaje solicitado. Tarifa demostrativa: ${money(res.data.fareMinorUnits, country)}.`);
  });
  const acceptTrip = (id: string) => run(async () => {
    await callable<{ tripId: string }, { ok: boolean }>('acceptTrip')({ tripId: id });
    setTripId(id); setAvailableTrips((list) => list.filter((t) => t.tripId !== id));
  }, 'Viaje aceptado. Solo este conductor quedó asignado.');
  const pickedUp = () => tripId && run(async () => { await callable<{ tripId: string }, { status: string }>('markTripPickedUp')({ tripId }); }, 'Recogida confirmada; viaje en curso.');
  const completeTrip = () => tripId && run(async () => {
    const res = await callable<{ tripId: string }, { commissionMinorUnits: number; newBalanceMinorUnits: number; currency: string; driverBlocked: boolean; alreadyCompleted?: boolean }>('completeTrip')({ tripId });
    setWallet(res.data.newBalanceMinorUnits ?? wallet); setAvailable(false);
    if (res.data.driverBlocked) { setActive(false); setNotice(`Viaje finalizado. Comisión ${money(res.data.commissionMinorUnits, country)}. Saldo negativo: cuenta bloqueada.`); }
    else setNotice(`Viaje finalizado. Comisión ${money(res.data.commissionMinorUnits, country)} aplicada${res.data.alreadyCompleted ? ' (ya procesada; no se duplicó)' : ''}.`);
  });
  const toggleAvailability = () => run(async () => {
    const next = !available;
    await callable<{ available: boolean }, { available: boolean }>('setDriverAvailability')({ available: next });
    setAvailable(next);
    if (next) { const result = await callable<Record<string, never>, { trips: Trip[] }>('listAvailableTrips')({}); setAvailableTrips(result.data.trips); }
  }, available ? 'Ahora estás desconectado.' : 'Ahora estás disponible para recibir viajes.');
  const pill = (label: string, selected: boolean, onPress: () => void) => <TouchableOpacity key={label} onPress={onPress} style={[s.pill, selected && s.pillActive]}><Text style={[s.pillText, selected && s.pillTextActive]}>{label}</Text></TouchableOpacity>;
  const action = (label: string, onPress: () => void, secondary = false) => <TouchableOpacity disabled={busy} onPress={onPress} style={[s.button, secondary && s.secondary, busy && { opacity: 0.55 }]}><Text style={[s.buttonText, secondary && s.secondaryText]}>{busy ? 'Procesando…' : label}</Text></TouchableOpacity>;
  const card = (title: string, body: React.ReactNode) => <View style={s.card}><Text style={s.cardTitle}>{title}</Text>{body}</View>;
  const currentCountry = countries[country];

  if (!firebaseConfigured) return <SafeAreaView style={s.safe}><View style={s.container}><Text style={s.brand}>moto<Text style={{ color: '#12a889' }}>go</Text></Text><Text style={s.cardTitle}>Configura Firebase</Text><Text style={s.body}>{firebaseConfigError}</Text><Text style={s.body}>Copia apps/mobile/.env.example a apps/mobile/.env e completa las credenciales de tu proyecto Firebase. Después reinicia Expo.</Text></View></SafeAreaView>;
  if (!user || !profileReady) return <SafeAreaView style={s.safe}><StatusBar barStyle="dark-content"/><ScrollView contentContainerStyle={s.container}><Text style={s.brand}>moto<Text style={{ color: '#12a889' }}>go</Text></Text><Text style={s.sub}>Movilidad sobre dos ruedas · Chile, Colombia y Perú</Text>
    {!user && <>{card(authMode === 'signup' ? 'Crear cuenta' : 'Iniciar sesión', <>
      {authMode === 'signup' && <><Text style={s.inputLabel}>Nombre</Text><TextInput value={displayName} onChangeText={setDisplayName} style={s.input} placeholder="Tu nombre"/><Text style={s.inputLabel}>Tipo de cuenta</Text><View style={s.roleRow}>{pill('Pasajero', role === 'passenger', () => setRole('passenger'))}{pill('Conductor', role === 'rider', () => setRole('rider'))}</View><Text style={s.inputLabel}>País</Text><View style={s.roleRow}>{(['CL', 'CO', 'PE'] as Country[]).map(c => pill(c, country === c, () => setCountry(c)))}</View></>}
      <Text style={s.inputLabel}>Correo electrónico</Text><TextInput value={email} onChangeText={setEmail} style={s.input} autoCapitalize="none" keyboardType="email-address" placeholder="correo@ejemplo.com"/><Text style={s.inputLabel}>Contraseña (mínimo 6 caracteres)</Text><TextInput value={password} onChangeText={setPassword} style={s.input} secureTextEntry placeholder="Contraseña"/>{action(authMode === 'signup' ? 'Crear cuenta' : 'Entrar', handleAuth)}{action(authMode === 'signup' ? 'Ya tengo cuenta · Iniciar sesión' : 'Crear una cuenta nueva', () => setAuthMode(authMode === 'signup' ? 'login' : 'signup'), true)}</>)}
      {busy && <ActivityIndicator/>}{error ? <Text style={s.error}>{error}</Text> : null}{notice ? <Text style={s.notice}>{notice}</Text> : null}</>}
    {user && <ActivityIndicator/>}</ScrollView></SafeAreaView>;

  const liveTrip = trip && trip.estado !== 'completado';
  return <SafeAreaView style={s.safe}><StatusBar barStyle="dark-content"/><ScrollView contentContainerStyle={s.container}>
    <View style={s.header}><View><Text style={s.brand}>moto<Text style={{ color: '#12a889' }}>go</Text></Text><Text style={s.sub}>{user.email} · {currentCountry.name}</Text></View>{action('Salir', logout, true)}</View>
    <View style={s.roleRow}>{pill('Pasajero', role === 'passenger', () => { setRole('passenger'); setNotice('Vista pasajero.'); })}{approved && pill('Conductor', role === 'rider', () => setRole('rider'))}{isAdmin && pill('Propietario', role === 'owner', () => setRole('owner'))}</View>
    {notice ? <Text style={s.notice}>{notice}</Text> : null}{error ? <Text style={s.error}>{error}</Text> : null}
    {role === 'passenger' && <>
      <View style={s.hero}><Text style={s.eyebrow}>TU CIUDAD, A TU RITMO</Text><Text style={s.heroTitle}>¿A dónde vamos?</Text><Text style={s.heroText}>Solicita una moto y paga directamente en efectivo.</Text><View style={s.mapMock}><View style={s.roadA}/><View style={s.roadB}/><View style={s.roadC}/><View style={s.mapPin}><Text>●</Text></View><View style={s.mapTag}><Text style={s.mapTagText}>Mapa de vista previa</Text></View></View></View>
      {card('Planifica tu viaje', <><Text style={s.inputLabel}>País</Text><View style={s.roleRow}>{(['CL', 'CO', 'PE'] as Country[]).map(c => pill(c, country === c, () => setCountry(c)))}</View><Text style={s.inputLabel}>Punto de recogida</Text><TextInput value={origin} onChangeText={setOrigin} style={s.input} placeholder="¿Dónde te recogemos?"/><Text style={s.inputLabel}>Destino</Text><TextInput value={destination} onChangeText={setDestination} style={s.input} placeholder="Ingresa tu destino"/>{action('Solicitar moto', requestTrip)}</>)}
      {trip && card('Estado del viaje', <><Text style={s.price}>{money(trip.tarifa_minor_units, trip.pais)}</Text><Text style={s.body}>Estado: {trip.estado}</Text><Text style={s.body}>Origen: {trip.origen}</Text><Text style={s.body}>Destino: {trip.destino}</Text>{trip.estado === 'completado' ? <Text style={s.good}>Viaje completado</Text> : <Text style={s.muted}>El estado se actualiza en tiempo real desde Firestore.</Text>}{trip.estado === 'completado' && action('Solicitar otro viaje', () => { setTripId(''); setTrip(null); setDestination(''); }, true)}</>)}
    </>}
    {role === 'rider' && <>
      {card('Estado del conductor', <><Text style={s.body}>Aprobación: {approved ? 'Aprobado' : 'Pendiente de aprobación administrativa'}</Text><Text style={s.body}>Cuenta activa: {active ? 'Sí' : 'No'}</Text><Text style={s.body}>Saldo interno: {money(wallet, country)}</Text>{approved && active && action(available ? 'Desconectarme' : 'Conectarme', toggleAvailability, !available)}{!approved && <Text style={s.error}>Tu perfil debe ser aprobado por el propietario antes de recibir viajes.</Text>}</>)}
      {liveTrip && trip?.conductor_id === user.uid && card('Tu viaje asignado', <><Text style={s.price}>{money(trip.tarifa_minor_units, trip.pais)}</Text><Text style={s.body}>Origen: {trip.origen}</Text><Text style={s.body}>Destino: {trip.destino}</Text><Text style={s.body}>Estado: {trip.estado}</Text>{trip.estado === 'aceptado' && action('Confirmar recogida', pickedUp)}{trip.estado === 'en_curso' && action('Finalizar viaje y aplicar comisión', completeTrip)}</>)}
      {card('Solicitudes disponibles', <>{availableTrips.length === 0 ? <Text style={s.body}>{available ? 'No hay solicitudes pendientes en este momento.' : 'Conéctate para ver solicitudes. La lista se actualiza cada 6 segundos.'}</Text> : availableTrips.map(t => <View key={t.tripId} style={s.tripItem}><Text style={s.cardTitle}>{money(t.tarifa_minor_units, t.pais)}</Text><Text style={s.body}>{t.origen} → {t.destino}</Text>{action('Aceptar este viaje', () => acceptTrip(t.tripId))}</View>)}</>)}
      {trip?.estado === 'completado' && <Text style={s.good}>Último viaje completado. Comisión: {money(trip.comision_minor_units, trip.pais)}.</Text>}
    </>}
    {role === 'owner' && isAdmin && <>{card('Panel de propietario', <><Text style={s.body}>Sesión administrativa verificada mediante custom claim.</Text><Text style={s.body}>El panel web administrativo se conecta por separado; aquí no se muestran métricas inventadas.</Text></>)}{card('Aprobación de conductores', <Text style={s.body}>La aprobación debe ejecutarse desde el backend administrativo con custom claim admin. No puede habilitarse desde la app pública.</Text>)}</>}
    <Text style={s.footer}>MotoGo · Flujo de viaje conectado a Firebase · {currentCountry.name}</Text>
  </ScrollView></SafeAreaView>;
}
const s = StyleSheet.create({ safe: { flex: 1, backgroundColor: '#f4f7f8' }, container: { padding: 18, paddingBottom: 36, gap: 14 }, header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }, brand: { fontSize: 29, fontWeight: '900', color: '#102b3f', letterSpacing: -1 }, sub: { fontSize: 12, color: '#64748b', marginTop: 3 }, roleRow: { flexDirection: 'row', gap: 7, flexWrap: 'wrap' }, pill: { borderRadius: 99, borderWidth: 1, borderColor: '#dbe3e8', backgroundColor: '#fff', paddingVertical: 9, paddingHorizontal: 12, marginBottom: 5 }, pillActive: { backgroundColor: '#102b3f', borderColor: '#102b3f' }, pillText: { fontSize: 12, color: '#475569', fontWeight: '700' }, pillTextActive: { color: '#fff' }, hero: { backgroundColor: '#102b3f', borderRadius: 22, padding: 20, overflow: 'hidden' }, eyebrow: { fontSize: 10, letterSpacing: 1.5, color: '#73e0c4', fontWeight: '800' }, heroTitle: { fontSize: 28, color: '#fff', fontWeight: '900', marginTop: 8 }, heroText: { fontSize: 13, color: '#d0dce4', lineHeight: 19, marginTop: 5 }, mapMock: { height: 140, backgroundColor: '#dcebe7', borderRadius: 14, marginTop: 18, overflow: 'hidden' }, roadA: { position: 'absolute', width: 440, height: 18, backgroundColor: '#fff', top: 56, left: -45, transform: [{ rotate: '-18deg' }] }, roadB: { position: 'absolute', width: 320, height: 15, backgroundColor: '#fff', top: 65, left: 20, transform: [{ rotate: '45deg' }] }, roadC: { position: 'absolute', width: 300, height: 11, backgroundColor: '#c5d8d3', top: 100, left: -30, transform: [{ rotate: '-35deg' }] }, mapPin: { position: 'absolute', top: 52, left: '53%', width: 28, height: 28, borderRadius: 14, backgroundColor: '#12a889', alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: '#fff' }, mapTag: { position: 'absolute', bottom: 8, left: 8, backgroundColor: '#fff', paddingHorizontal: 9, paddingVertical: 5, borderRadius: 8 }, mapTagText: { fontSize: 10, color: '#475569', fontWeight: '700' }, card: { backgroundColor: '#fff', borderRadius: 18, padding: 16, borderWidth: 1, borderColor: '#e6ecef' }, cardTitle: { fontSize: 16, fontWeight: '800', color: '#102b3f', marginBottom: 12 }, inputLabel: { fontSize: 11, fontWeight: '800', color: '#64748b', marginTop: 6, marginBottom: 5 }, input: { borderWidth: 1, borderColor: '#dbe3e8', borderRadius: 12, paddingHorizontal: 13, paddingVertical: 12, color: '#102b3f', fontSize: 14, marginBottom: 8, backgroundColor: '#fbfcfd' }, button: { backgroundColor: '#12a889', borderRadius: 12, paddingVertical: 13, paddingHorizontal: 14, alignItems: 'center', justifyContent: 'center', marginTop: 8 }, buttonText: { color: '#fff', fontWeight: '800', fontSize: 13 }, secondary: { backgroundColor: '#f1f5f7', borderWidth: 1, borderColor: '#dbe3e8' }, secondaryText: { color: '#102b3f' }, muted: { fontSize: 11, color: '#64748b' }, price: { fontSize: 20, fontWeight: '900', color: '#102b3f', marginTop: 4, marginBottom: 7 }, body: { fontSize: 13, color: '#475569', lineHeight: 19, marginBottom: 6 }, notice: { backgroundColor: '#e4f6f0', color: '#126b59', padding: 11, borderRadius: 10, fontSize: 12 }, error: { backgroundColor: '#fee2e2', color: '#991b1b', padding: 11, borderRadius: 10, fontSize: 12 }, good: { fontSize: 13, color: '#0b987a', marginTop: 4, fontWeight: '800' }, tripItem: { borderTopWidth: 1, borderTopColor: '#eef2f4', paddingTop: 12, marginTop: 8 }, footer: { textAlign: 'center', fontSize: 10, color: '#94a3b8', marginTop: 8 } });
