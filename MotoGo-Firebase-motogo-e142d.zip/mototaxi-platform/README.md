# MotoGo — MVP de flujo de viaje

Base de desarrollo para una plataforma de mototaxi en Chile (CLP), Colombia (COP) y Perú (PEN), con tres interfaces: pasajero, conductor/rider y propietario. La comisión de plataforma es del 15%.

## Flujo incluido

1. Pasajero crea una solicitud (`solicitado`).
2. Un conductor aprobado, activo, disponible y con saldo no negativo acepta (`aceptado`). La transacción impide que dos conductores acepten el mismo viaje.
3. El conductor confirma la recogida (`en_curso`).
4. El conductor finaliza el viaje (`completado`). En una única transacción se registra la comisión del 15%, se actualiza el saldo interno y se crea una entrada inmutable en `wallet_ledger`.
5. Si el saldo resultante es negativo, se bloquea el conductor (`estado_activo: false`, `disponible: false`). Las funciones de disponibilidad y aceptación vuelven a validar esos campos en el servidor.

Los endpoints `completeTrip` y `processTripCommission` evitan cobrar dos veces. La función de disparador es una salvaguarda de diagnóstico; el camino recomendado es `completeTrip`, que actualiza viaje, saldo y libro contable atómicamente.

## Funciones callable

- `requestTrip({ country, origin, destination })`: crea solicitud. La tarifa es fija y demostrativa por país; no acepta tarifa del cliente.
- `acceptTrip({ tripId })`: aceptación atómica por el conductor autenticado.
- `markTripPickedUp({ tripId })`: confirma recogida.
- `completeTrip({ tripId })`: finaliza y aplica comisión exactamente una vez.
- `setDriverAvailability({ available })`: controla disponibilidad con validación de aprobación y saldo.

Todas las funciones callable exigen Firebase Authentication. Para facilitar el MVP, App Check está temporalmente desactivado en las funciones callable; antes de producción debes integrar App Check para React Native y cambiar `enforceAppCheck` a `true`. No publiques el backend en producción con esta protección desactivada.

## Tarifas de demostración

En `functions/index.js`, `COUNTRIES` contiene tarifas fijas de ejemplo: Chile 4.500 CLP, Colombia 9.000 COP y Perú 8,00 PEN. No representan una tarifa comercial real ni calculan distancia. Sustituye esta tabla por un motor de tarifas de servidor antes de aceptar viajes reales. PEN se representa en céntimos; CLP/COP, en unidades enteras.

## Modelo de datos esperado

- `users/{uid}`: perfil con `role: "passenger"` para solicitar viajes.
- `conductores/{uid}`: `approved`, `estado_activo`, `disponible`, `saldo_billetera_interna_minor_units`, y opcionalmente `country`.
- `viajes/{tripId}`: pasajero, conductor, país, estado, origen, destino, tarifa, moneda y comisión.
- `wallet_ledger/{entryId}`: registro de movimientos generado solo por backend.

Los perfiles y claims deben crearse mediante un proceso de backend confiable. No permitas que el cliente se otorgue el rol de administrador o cambie su saldo.

## Instalar y desplegar backend

Requisitos: Node.js 20+, Firebase CLI y proyecto Firebase propio.

```bash
cd functions
npm install
cd ..
firebase login
firebase use --add
firebase deploy --only firestore:rules,functions
```

Configura Authentication, App Check, Firestore y los claims administrativos antes de desplegar. La región configurada es `southamerica-west1` (São Paulo); ajusta región y ubicación de datos según tu arquitectura.

## Conectar y ejecutar la app móvil con Firebase

1. En Firebase Console, crea un proyecto, habilita Authentication > Email/Password y crea Firestore.
2. Copia `apps/mobile/.env.example` a `apps/mobile/.env` y rellena las variables con la configuración de la app web Firebase.
3. Instala y ejecuta:

```bash
cd apps/mobile
npm install
npx expo start
```

La app usa Firebase Authentication con persistencia de sesión en AsyncStorage y callable functions en `southamerica-west1`. `registerProfile` crea perfiles de pasajero o conductor sin permitir que el cliente se otorgue el rol de administrador. Los conductores nuevos quedan pendientes de aprobación y necesitan saldo válido antes de conectarse. El propietario requiere el custom claim `admin: true`, asignado desde un entorno confiable con Firebase Admin SDK.

Las llamadas `requestTrip`, `acceptTrip`, `markTripPickedUp` y `completeTrip` pasan por el backend; el estado del viaje asignado se observa en tiempo real con Firestore. El listado de solicitudes del conductor se refresca cada seis segundos mediante `listAvailableTrips`.

## Prueba de concurrencia con Firebase Emulator Suite

Requisitos: Firebase CLI, Java para el emulador de Firestore y Node.js 20+.

```bash
cd tests
npm install
cd ..
firebase emulators:exec --project demo-motogo --only auth,firestore,functions "cd tests && npm run test:emulator"
```

La prueba crea un pasajero y dos conductores de prueba, solicita un viaje y envía ambas aceptaciones en paralelo. Debe ganar exactamente un conductor. Luego finaliza el viaje dos veces en paralelo y verifica que el saldo solo descuente 675 CLP (15 % de 4.500 CLP) y que exista una única entrada en `wallet_ledger`.

Los datos de tarifas son fijos de demostración. No representan cotizaciones por distancia ni una tarifa comercial lista para producción.

## Ejecutar panel web

```bash
cd apps/admin
npm install
npm run dev
```

## Antes de producción

- Conectar interfaces a Authentication, Firestore y funciones callable.
- Implementar motor de rutas/distancias, mapas, geolocalización y notificaciones push.
- Implementar recargas verificadas y proceso de conciliación; no aceptar recargas declaradas por el cliente.
- Conectar métricas administrativas a datos reales y proteger acciones con custom claims.
- Añadir pruebas de concurrencia, reglas de seguridad, auditoría, monitoreo y revisión legal/tributaria para los tres países.

## Preparación de release para Google Play

Se añadieron `app.config.js`, `eas.json`, iconos provisionales y `PLAY_STORE_RELEASE.md` con el proceso de compilación y la lista de requisitos de publicación. Copia `apps/mobile/.env.example` a `apps/mobile/.env`, rellena las variables y sustituye `EAS_PROJECT_ID` con el identificador real creado por EAS. El package ID provisional es `com.motogo.app`: confirma su disponibilidad antes de publicar.

**No es todavía una versión lista para producción.** Requiere un proyecto Firebase real, configuración y pruebas de App Check, ejecutar el test de Emulator, integrar mapas/GPS/notificaciones reales, revisar legalmente la política de privacidad y completar las declaraciones y pruebas de Google Play. Consulta `PLAY_STORE_RELEASE.md`.

## Conectar al proyecto Firebase existente

El proyecto Firebase predeterminado ya está configurado como `motogo-e142d` en `.firebaserc`.

1. En Firebase Console abre **Configuración del proyecto → General → Tus apps** y registra una app web (icono `</>`), por ejemplo `MotoGo Mobile Config`.
2. Copia los valores `apiKey`, `authDomain`, `appId` y `messagingSenderId` de la configuración web. Son identificadores de configuración de Firebase, no una cuenta de servicio. Nunca compartas claves privadas ni archivos JSON de service account.
3. Copia `apps/mobile/.env.example` a `apps/mobile/.env` y completa esos cuatro valores. `EXPO_PUBLIC_FIREBASE_PROJECT_ID` ya está prellenado como `motogo-e142d`.
4. Desde `apps/mobile`, ejecuta `npm install`, `npx expo start` y prueba registro/inicio de sesión con una cuenta de prueba.
5. Desde la raíz, ejecuta `npm install -g firebase-tools` si hace falta, `firebase login`, revisa las reglas y despliega con `firebase deploy --only firestore:rules,functions`.

**Importante:** no despliegues a usuarios reales todavía. Las funciones de este MVP tienen App Check desactivado para pruebas y usan tarifas fijas de demostración; además debes probar el flujo con Firebase Emulator, configurar App Check, revisar las reglas y completar privacidad/seguridad antes de producción.
