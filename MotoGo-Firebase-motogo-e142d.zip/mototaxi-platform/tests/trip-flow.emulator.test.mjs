import test from 'node:test';
import assert from 'node:assert/strict';
import { initializeApp, deleteApp } from 'firebase/app';
import { getAuth, connectAuthEmulator, createUserWithEmailAndPassword } from 'firebase/auth';
import { getFunctions, connectFunctionsEmulator, httpsCallable } from 'firebase/functions';
import { initializeApp as initializeAdminApp, deleteApp as deleteAdminApp } from 'firebase-admin/app';
import { getFirestore as getAdminFirestore, FieldValue } from 'firebase-admin/firestore';

const projectId = process.env.GCLOUD_PROJECT || 'demo-motogo';
const clients = [];
const adminApp = initializeAdminApp({ projectId }, `admin-${Date.now()}`);
const db = getAdminFirestore(adminApp);

async function makeUser(label, role) {
  const app = initializeApp({ projectId, apiKey: 'demo-api-key', appId: `demo-${label}-${Date.now()}`, authDomain: `${projectId}.firebaseapp.com` }, `client-${label}-${Date.now()}`);
  clients.push(app);
  const auth = getAuth(app);
  connectAuthEmulator(auth, process.env.FIREBASE_AUTH_EMULATOR_HOST ? `http://${process.env.FIREBASE_AUTH_EMULATOR_HOST}` : 'http://127.0.0.1:9099', { disableWarnings: true });
  const functions = getFunctions(app, 'southamerica-west1');
  connectFunctionsEmulator(functions, '127.0.0.1', 5001);
  const credential = await createUserWithEmailAndPassword(auth, `${label.replace(/\s/g, '').toLowerCase()}-${Date.now()}@example.test`, 'TestPassword123!');
  const call = (name, data = {}) => httpsCallable(functions, name)(data);
  await call('registerProfile', { role, displayName: label, country: 'CL' });
  return { user: credential.user, auth, call };
}

test('solo un conductor acepta el viaje y la comisión se aplica exactamente una vez', async (t) => {
  t.after(async () => {
    await Promise.all(clients.map((client) => deleteApp(client).catch(() => {})));
    await deleteAdminApp(adminApp);
  });

  const passenger = await makeUser('Pasajero test', 'passenger');
  const driver1 = await makeUser('Conductor uno', 'rider');
  const driver2 = await makeUser('Conductor dos', 'rider');

  for (const driver of [driver1, driver2]) {
    await db.collection('conductores').doc(driver.user.uid).set({
      approved: true, estado_activo: true, disponible: true,
      saldo_billetera_interna_minor_units: 100000, country: 'CL',
      createdAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(),
    }, { merge: true });
  }

  const created = await passenger.call('requestTrip', { country: 'CL', origin: 'Plaza de prueba', destination: 'Terminal de prueba' });
  const tripId = created.data.tripId;
  assert.ok(tripId);

  // Both callable requests are issued concurrently with distinct authenticated clients.
  const outcomes = await Promise.allSettled([
    driver1.call('acceptTrip', { tripId }),
    driver2.call('acceptTrip', { tripId }),
  ]);
  const winners = outcomes.filter((x) => x.status === 'fulfilled');
  const losers = outcomes.filter((x) => x.status === 'rejected');
  assert.equal(winners.length, 1, 'exactamente un conductor debe aceptar');
  assert.equal(losers.length, 1, 'el otro conductor debe ser rechazado');

  const tripSnap = await db.collection('viajes').doc(tripId).get();
  const assignedDriverId = tripSnap.data().conductor_id;
  assert.ok([driver1.user.uid, driver2.user.uid].includes(assignedDriverId));
  assert.equal(tripSnap.data().estado, 'aceptado');
  const assignedDriver = assignedDriverId === driver1.user.uid ? driver1 : driver2;
  await assignedDriver.call('markTripPickedUp', { tripId });
  const completions = await Promise.all([
    assignedDriver.call('completeTrip', { tripId }),
    assignedDriver.call('completeTrip', { tripId }),
  ]);
  assert.equal(completions.length, 2);

  const finalTrip = (await db.collection('viajes').doc(tripId).get()).data();
  assert.equal(finalTrip.estado, 'completado');
  assert.equal(finalTrip.comision_aplicada, true);
  assert.equal(finalTrip.comision_minor_units, 675); // 15% de 4.500 CLP
  const driverDoc = (await db.collection('conductores').doc(assignedDriverId).get()).data();
  assert.equal(driverDoc.saldo_billetera_interna_minor_units, 99325);
  const ledger = await db.collection('wallet_ledger').where('trip_id', '==', tripId).get();
  assert.equal(ledger.size, 1, 'debe existir exactamente un movimiento de comisión');
});
