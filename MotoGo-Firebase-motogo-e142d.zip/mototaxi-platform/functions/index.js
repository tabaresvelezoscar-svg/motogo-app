const { onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const logger = require('firebase-functions/logger');

initializeApp();
const db = getFirestore();
const COMMISSION_PERCENT = 15;
const REGION = 'southamerica-west1';
const COUNTRIES = {
  CL: { currency: 'CLP', fareMinorUnits: 4500 },
  CO: { currency: 'COP', fareMinorUnits: 9000 },
  PE: { currency: 'PEN', fareMinorUnits: 800 }, // 8.00 PEN in céntimos
};
const validText = (value, max = 180) => typeof value === 'string' && value.trim().length > 0 && value.trim().length <= max;

function requireAuth(request) {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Debes iniciar sesión.');
  return request.auth.uid;
}

// Passenger requests a trip. Fare is server-calculated (demo fixed tariff); never trust client fare.
exports.requestTrip = onCall({ region: REGION, enforceAppCheck: false }, async (request) => {
  const uid = requireAuth(request);
  const { country, origin, destination } = request.data || {};
  const countryCode = String(country || '').toUpperCase();
  const cfg = COUNTRIES[countryCode];
  if (!cfg) throw new HttpsError('invalid-argument', 'País no soportado.');
  if (!validText(origin) || !validText(destination)) throw new HttpsError('invalid-argument', 'Indica un origen y destino válidos.');
  if (origin.trim().toLowerCase() === destination.trim().toLowerCase()) throw new HttpsError('invalid-argument', 'El origen y destino deben ser diferentes.');

  const passengerSnap = await db.collection('users').doc(uid).get();
  if (!passengerSnap.exists || passengerSnap.data().role !== 'passenger') {
    throw new HttpsError('permission-denied', 'La cuenta debe tener el perfil pasajero.');
  }
  const tripRef = db.collection('viajes').doc();
  await tripRef.create({
    pasajero_id: uid,
    conductor_id: null,
    pais: countryCode,
    moneda: cfg.currency,
    estado: 'solicitado',
    origen: origin.trim(),
    destino: destination.trim(),
    tarifa_minor_units: cfg.fareMinorUnits,
    comision_porcentaje: COMMISSION_PERCENT,
    comision_aplicada: false,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });
  return { tripId: tripRef.id, status: 'solicitado', fareMinorUnits: cfg.fareMinorUnits, currency: cfg.currency };
});

// Driver accepts one requested trip; transaction prevents two drivers accepting it.
exports.acceptTrip = onCall({ region: REGION, enforceAppCheck: false }, async (request) => {
  const uid = requireAuth(request);
  const { tripId } = request.data || {};
  if (!validText(tripId, 128)) throw new HttpsError('invalid-argument', 'tripId no válido.');
  const tripRef = db.collection('viajes').doc(tripId);
  const driverRef = db.collection('conductores').doc(uid);
  await db.runTransaction(async (tx) => {
    const tripSnap = await tx.get(tripRef);
    const driverSnap = await tx.get(driverRef);
    if (!tripSnap.exists) throw new HttpsError('not-found', 'Viaje no encontrado.');
    if (!driverSnap.exists) throw new HttpsError('permission-denied', 'Perfil de conductor no encontrado.');
    const trip = tripSnap.data();
    const driver = driverSnap.data();
    if (trip.estado !== 'solicitado' || trip.conductor_id) throw new HttpsError('failed-precondition', 'Este viaje ya fue asignado o no está disponible.');
    if (driver.approved !== true || driver.estado_activo !== true || driver.disponible !== true) throw new HttpsError('permission-denied', 'Debes estar aprobado, activo y disponible.');
    if (!Number.isSafeInteger(driver.saldo_billetera_interna_minor_units) || driver.saldo_billetera_interna_minor_units < 0) throw new HttpsError('failed-precondition', 'Saldo insuficiente: recarga tu billetera antes de recibir viajes.');
    if (driver.country && driver.country !== trip.pais) throw new HttpsError('failed-precondition', 'Tu país no coincide con el viaje.');
    tx.update(tripRef, { conductor_id: uid, estado: 'aceptado', aceptado_en: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp() });
    tx.update(driverRef, { disponible: false, updatedAt: FieldValue.serverTimestamp() });
  });
  return { ok: true, status: 'aceptado' };
});

// Driver confirms passenger pickup: accepted -> en_curso.
exports.markTripPickedUp = onCall({ region: REGION, enforceAppCheck: false }, async (request) => {
  const uid = requireAuth(request);
  const { tripId } = request.data || {};
  if (!validText(tripId, 128)) throw new HttpsError('invalid-argument', 'tripId no válido.');
  const ref = db.collection('viajes').doc(tripId);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError('not-found', 'Viaje no encontrado.');
    const trip = snap.data();
    if (trip.conductor_id !== uid) throw new HttpsError('permission-denied', 'Solo el conductor asignado puede iniciar el viaje.');
    if (trip.estado !== 'aceptado') throw new HttpsError('failed-precondition', 'El viaje debe estar aceptado para iniciar.');
    tx.update(ref, { estado: 'en_curso', recogida_confirmada_en: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp() });
  });
  return { ok: true, status: 'en_curso' };
});

// Complete trip and apply commission atomically, exactly once.
exports.completeTrip = onCall({ region: REGION, enforceAppCheck: false }, async (request) => {
  const uid = requireAuth(request);
  const { tripId } = request.data || {};
  if (!validText(tripId, 128)) throw new HttpsError('invalid-argument', 'tripId no válido.');
  const tripRef = db.collection('viajes').doc(tripId);
  const result = await db.runTransaction(async (tx) => {
    const tripSnap = await tx.get(tripRef);
    if (!tripSnap.exists) throw new HttpsError('not-found', 'Viaje no encontrado.');
    const trip = tripSnap.data();
    if (trip.conductor_id !== uid) throw new HttpsError('permission-denied', 'Solo el conductor asignado puede finalizar el viaje.');
    if (trip.estado === 'completado' && trip.comision_aplicada === true) return { alreadyCompleted: true, commissionMinorUnits: trip.comision_minor_units, currency: trip.moneda };
    if (trip.estado !== 'en_curso') throw new HttpsError('failed-precondition', 'El viaje debe estar en curso para finalizar.');
    const cfg = COUNTRIES[trip.pais];
    const fare = trip.tarifa_minor_units;
    if (!cfg || !Number.isSafeInteger(fare) || fare < 0) throw new HttpsError('failed-precondition', 'País o tarifa inválidos.');
    const driverRef = db.collection('conductores').doc(uid);
    const driverSnap = await tx.get(driverRef);
    if (!driverSnap.exists) throw new HttpsError('not-found', 'Perfil de conductor no encontrado.');
    const balance = driverSnap.data().saldo_billetera_interna_minor_units;
    if (!Number.isSafeInteger(balance)) throw new HttpsError('failed-precondition', 'Saldo de billetera inválido.');
    const commission = Math.round(fare * COMMISSION_PERCENT / 100);
    const newBalance = balance - commission;
    const ledgerRef = db.collection('wallet_ledger').doc(`commission_${tripRef.id}`);
    tx.update(driverRef, {
      saldo_billetera_interna_minor_units: newBalance,
      ...(newBalance < 0 ? { estado_activo: false, disponible: false } : {}),
      ...(newBalance >= 0 ? { disponible: false } : {}),
      updatedAt: FieldValue.serverTimestamp(),
    });
    tx.update(tripRef, {
      estado: 'completado', comision_aplicada: true,
      comision_porcentaje: COMMISSION_PERCENT,
      comision_minor_units: commission, moneda: cfg.currency,
      saldo_despues_comision_minor_units: newBalance,
      comision_procesada_en: FieldValue.serverTimestamp(),
      finalizado_en: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(),
    });
    tx.create(ledgerRef, {
      entry_id: `commission_${tripRef.id}`, trip_id: tripRef.id, user_id: uid,
      country: trip.pais, currency: cfg.currency, type: 'trip_commission',
      amount_minor_units: -commission, balance_after_minor_units: newBalance,
      createdAt: FieldValue.serverTimestamp(),
    });
    return { alreadyCompleted: false, commissionMinorUnits: commission, newBalanceMinorUnits: newBalance, currency: cfg.currency, driverBlocked: newBalance < 0 };
  });
  logger.info('Trip completed and commission processed', { tripId, driverId: uid, ...result });
  return { ok: true, status: 'completado', ...result };
});

// Defensive fallback for trips completed by a trusted migration/admin workflow.
// Callable completion is preferred because status + wallet + ledger commit atomically.
exports.processTripCommission = onDocumentUpdated({ document: 'viajes/{tripId}', region: REGION }, async (event) => {
  const before = event.data?.before.data();
  const after = event.data?.after.data();
  if (!before || !after || after.estado !== 'completado' || before.estado === 'completado' || after.comision_aplicada === true) return;
  logger.error('Completed trip without commission marker; investigate trusted write path', { tripId: event.params.tripId });
});

exports.setDriverAvailability = onCall({ region: REGION, enforceAppCheck: false }, async (request) => {
  const uid = requireAuth(request);
  const { available } = request.data || {};
  if (typeof available !== 'boolean') throw new HttpsError('invalid-argument', 'available debe ser booleano.');
  const ref = db.collection('conductores').doc(uid);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError('not-found', 'Perfil de conductor no encontrado.');
    const driver = snap.data();
    if (driver.approved !== true) throw new HttpsError('permission-denied', 'Conductor aún no aprobado.');
    if (driver.estado_activo !== true && available) throw new HttpsError('failed-precondition', 'Cuenta bloqueada por saldo o revisión.');
    if (available && (!Number.isSafeInteger(driver.saldo_billetera_interna_minor_units) || driver.saldo_billetera_interna_minor_units < 0)) throw new HttpsError('failed-precondition', 'Saldo insuficiente para conectarte.');
    tx.update(ref, { disponible: available, updatedAt: FieldValue.serverTimestamp() });
  });
  return { ok: true, available };
});


// Create a passenger or driver profile after Firebase Authentication sign-up.
// Admin role is intentionally never accepted from a client.
exports.registerProfile = onCall({ region: REGION, enforceAppCheck: false }, async (request) => {
  const uid = requireAuth(request);
  const { role, displayName, country } = request.data || {};
  if (!['passenger', 'rider'].includes(role)) throw new HttpsError('invalid-argument', 'Perfil no permitido.');
  if (!validText(displayName, 100)) throw new HttpsError('invalid-argument', 'Nombre no válido.');
  const countryCode = String(country || '').toUpperCase();
  if (!COUNTRIES[countryCode]) throw new HttpsError('invalid-argument', 'País no soportado.');
  const userRef = db.collection('users').doc(uid);
  const driverRef = db.collection('conductores').doc(uid);
  await db.runTransaction(async (tx) => {
    const userSnap = await tx.get(userRef);
    if (userSnap.exists) {
      if (userSnap.data().role !== role) throw new HttpsError('failed-precondition', 'El perfil ya existe con otro rol.');
      return;
    }
    tx.create(userRef, { role, displayName: displayName.trim(), country: countryCode, createdAt: FieldValue.serverTimestamp() });
    if (role === 'rider') tx.create(driverRef, {
      displayName: displayName.trim(), country: countryCode, approved: false,
      estado_activo: true, disponible: false, saldo_billetera_interna_minor_units: 0,
      createdAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(),
    });
  });
  return { ok: true, role };
});

// Drivers can discover requests without broad direct read access to passenger trips.
exports.listAvailableTrips = onCall({ region: REGION, enforceAppCheck: false }, async (request) => {
  const uid = requireAuth(request);
  const driverSnap = await db.collection('conductores').doc(uid).get();
  if (!driverSnap.exists) throw new HttpsError('permission-denied', 'Perfil de conductor no encontrado.');
  const driver = driverSnap.data();
  if (driver.approved !== true || driver.estado_activo !== true || driver.disponible !== true || !Number.isSafeInteger(driver.saldo_billetera_interna_minor_units) || driver.saldo_billetera_interna_minor_units < 0) {
    throw new HttpsError('failed-precondition', 'Debes estar aprobado, activo, disponible y tener saldo no negativo.');
  }
  const snap = await db.collection('viajes').where('estado', '==', 'solicitado').limit(30).get();
  return { trips: snap.docs.map((d) => { const t = d.data(); return { tripId: d.id, estado: t.estado, pais: t.pais, moneda: t.moneda, origen: t.origen, destino: t.destino, tarifa_minor_units: t.tarifa_minor_units, createdAt: t.createdAt?.toDate?.().toISOString?.() || null }; }).filter((t) => !driver.country || t.pais === driver.country) };
});
