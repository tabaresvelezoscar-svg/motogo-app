# MotoGo — preparación para Google Play

## Estado real
Este repositorio es un MVP técnico, **no está listo para producción ni se ha publicado**. Para generar el Android App Bundle se necesitan cuentas, identificadores y validaciones externas que no pueden crearse desde este repositorio.

## Identidad
- Nombre propuesto: MotoGo
- Paquete Android provisional: `com.motogo.app`
- Versión inicial: `1.0.0` / `versionCode: 1`
- Región de Functions: `southamerica-west1`
- Países de demostración: Chile (CLP), Colombia (COP), Perú (PEN)

**Importante:** confirmar que el nombre y el identificador de paquete están disponibles. No publicar hasta confirmar el paquete, ya que cambiarlo después requiere una app distinta.

## Configuración local
1. Instalar Node.js 20 LTS, Java requerido por Android/Firebase Emulator, Firebase CLI y EAS CLI.
2. Copiar `.env.example` a `.env` y completar las variables Firebase de una aplicación web registrada en Firebase. No incluir service-account JSON ni secretos en la app.
3. Crear un proyecto Firebase propio, activar Email/Password, crear Firestore, elegir la ubicación de datos y habilitar facturación/plan según los servicios usados.
4. Ejecutar `firebase login`, `firebase use --add` y seleccionar el proyecto real. El archivo `.firebaserc` se mantiene fuera de Git.
5. Desplegar reglas y funciones en un entorno de staging primero; ejecutar las pruebas del emulador y revisar logs.
6. Configurar App Check para React Native/Android con un proveedor compatible y exigirlo en funciones solo después de probarlo. No desplegar públicamente mientras `enforceAppCheck` sea `false`.
7. Crear proyecto Expo/EAS con `eas login` y `eas build:configure`; reemplazar `REPLACE_WITH_EAS_PROJECT_ID` con el ID real que genere EAS.

## Validaciones obligatorias antes de producción
- Corregir y ejecutar typecheck, build y pruebas automatizadas en CI.
- Probar el flujo completo en Android físico: registro, login, roles, solicitud, aceptación concurrente, recogida, finalización, comisión única, saldo negativo y recuperación tras recarga autorizada.
- Confirmar que solo un conductor puede aceptar un viaje; comprobar reintentos y fallos de red.
- Integrar mapas, rutas, ubicación y notificaciones push antes de anunciar seguimiento en tiempo real. La pantalla actual muestra un mapa de vista previa y no GPS real.
- Implementar flujo administrativo seguro para aprobar conductores, asignar claims, revisar saldos y recargas; la UI por sí sola no concede permisos.
- Definir tarifas comerciales reales, cancelaciones, soporte, seguridad vial, comprobación de conductores y seguros.
- Completar política de privacidad pública, correo de soporte, términos de servicio, clasificación de contenido/edad y formulario Data safety de Play según los SDK y datos realmente usados.
- Preparar icono 512×512, feature graphic 1024×500, capturas de pantalla reales y descripción en español. No usar capturas simuladas como si fueran la app final.
- Probar el Android App Bundle firmado en pista de pruebas internas y revisar informes de Play Console.
- Completar pruebas requeridas por Play Console para cuentas nuevas, declaraciones de permisos, información de contacto y requisitos vigentes de target API.

## Construcción de prueba
```bash
npm install -g eas-cli firebase-tools
cd apps/mobile
npm install
npx expo-doctor
npx tsc --noEmit
cd ../..
eas login
eas build:configure
eas build --platform android --profile preview
```

## Construcción para Play (solo después de completar todos los requisitos)
```bash
eas build --platform android --profile production
```
Esto debe producir un `.aab` firmado mediante las credenciales de EAS. No subas un build hasta completar pruebas y revisión de seguridad.

## Publicación
1. Crear/validar cuenta de desarrollador Google Play Console y verificar identidad.
2. Crear ficha de aplicación con paquete confirmado.
3. Completar clasificación de contenido, seguridad de datos, privacidad, acceso a la app, anuncios y permisos.
4. Subir AAB a pruebas internas; instalar desde Play y probar.
5. Resolver advertencias y requisitos de pruebas de la cuenta; después solicitar revisión/publicación.

## Datos que debe proporcionar el propietario
- Proyecto Firebase y su Project ID.
- ID de proyecto Expo/EAS.
- Identificador Android definitivo.
- Razón social/titular, correo de soporte y URL pública de privacidad.
- Tarifas comerciales, política de cancelaciones y proceso de recarga.
- Acceso del propietario a Google Play Console (no compartir contraseñas ni claves privadas en el chat).
